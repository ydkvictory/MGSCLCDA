MGSCLCDA is an innovative deep learning framework designed for predicting associations between circRNAs and diseases. By integrating advanced techniques such as multiscale graph convolutional networks, disentangled path encoding, and contrastive learning, the model achieves highly accurate prediction performance.

## Key Innovations
The MGSCLCDA model incorporates several technical innovations:

1. **Multiscale Graph Convolution Architecture**: Combines three types of graph convolutional layers—GIN, GCN, and GAT—to capture diverse structural features.

2. **Dynamic Adaptive Aggregation Mechanism**: Learns optimal fusion weights for different types of features automatically based on input characteristics.

3. **Disentangled Path Encoder**: Explicitly models multi-hop path information to enhance the expressiveness of structural dependencies.

4. **Graph Contrastive Learning Framework**: Employs self-supervised learning to improve generalization capability, particularly under data-limited scenarios.

5. **Collaborative Filtering–Enhanced Edge Decoder**: Captures complex interaction patterns between nodes by combining collaborative filtering with multi-layer perceptrons.


## Installation

### System Requirements

- Python 3.7+
- CUDA 10.2+ (用于GPU加速，推荐)
- CPU或GPU环境

### Dependency Installation

For CUDA 12.1, please use the following commands:

```bash
# Install PyTorch (compatible with CUDA 12.1)
pip install torch==2.1.0 torchvision==0.16.0 --index-url https://download.pytorch.org/whl/cu121

# Install PyTorch Geometric and its dependencies
pip install torch-geometric==2.4.0
pip install torch-scatter -f https://data.pyg.org/whl/torch-2.1.0+cu121.html
pip install torch-sparse -f https://data.pyg.org/whl/torch-2.1.0+cu121.html
pip install torch-cluster -f https://data.pyg.org/whl/torch-2.1.0+cu121.html
pip install torch-spline-conv -f https://data.pyg.org/whl/torch-2.1.0+cu121.html

# Install other required dependencies
pip install numpy pandas matplotlib scikit-learn
```

If you are using a different CUDA version, please refer to [the official PyTorch installation guide](https://pytorch.org/get-started/locally/) and [PyTorch Geometric installation documentation](https://pytorch-geometric.readthedocs.io/en/latest/install/installation.html) for appropriate versions.

## Data Preparation

MGSCLCDA requires the following input data:

1. **Interaction Data**: Known associations between circRNAs and diseases
2. **circRNA Features**: Feature matrix representing circRNA attributes
3. **疾病 Features**: Feature matrix representing disease attributes

The data should be organized in the following structure:

```
MGSCLCDA
  ├── dataset/
  │   ├── dataset1/
  │   │   ├── interaction_dataset1.csv  # circRNA-disease known associations
  │   │   ├── ml.csv                    # circRNA features matrix
  │   │   └── mp.csv                    # disease features matrix
  │   └── dataset2/
  │       ├── interaction_dataset2.csv  # circRNA-disease known associations
  │       ├── ml.csv                    # circRNA features matrix
  │       └── mp.csv                    # disease features matrix
```

### Data Format

- **interaction_datasetX.csv**：A binary matrix with circRNAs as rows and diseases as columns; values are 0 or 1, indicating absence or presence of known associations.
- **ml.csv**：Feature matrix for circRNAs, where each row represents a feature vector of a circRNA.
- **mp.csv**：Feature matrix for diseases, where each row represents a feature vector of a disease.


## Parameter Description

MGSCLCDA provides several configurable parameters to control training:

| Parameter | Type | Default | Description |
|------|------|--------|------|
| `--dataset` | int | 2 | Select the dataset (1 or 2) |
| `--seed` | int | 2023 | Random seed |
| `--dim` | int | 1050 | Feature dimension |
| `--alpha` | float | 0.007 | Weight of the degree prediction loss |
| `--contrastive_weight` | float | 0.1 | Weight of the contrastive loss |
| `--p` | float | 0.4 | Edge masking ratio |
| `--epochs` | int | 1000 | Number of training epochs |
| `--learning_rate` | float | 0.001 | Learning rate |
| `--weight_decay` | float | 5e-5 | Weight decay |
| `--hidden_dim` | int | 64 | Hidden layer dimension |
| `--output_dim` | int | 128 | Output dimension |

