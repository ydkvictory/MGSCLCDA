import torch
import random
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import torch_geometric.transforms as T
from torch_geometric.data import Data


def set_seed(seed):
    """Set all random seeds to ensure reproducibility"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def setup_logger(name):
    """Create and configure a logger"""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    file_handler = logging.FileHandler(f'{name}_log.txt')
    file_handler.setLevel(logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)
    
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger


def calculate_metrics(y_true, y_pred):
    """Calculate classification performance metrics"""
    TP, TN, FP, FN = 0, 0, 0, 0
    for i in range(len(y_true)):
        if y_true[i] == 1 and y_pred[i] == 1:
            TP += 1
        if y_true[i] == 0 and y_pred[i] == 0:
            TN += 1
        if y_true[i] == 0 and y_pred[i] == 1:
            FP += 1
        if y_true[i] == 1 and y_pred[i] == 0:
            FN += 1
    accuracy = (TP + TN) / (TP + TN + FP + FN + 1e-10)
    sensitivity = TP / (TP + FN + 1e-10)
    precision = TP / (TP + FP + 1e-10)
    specificity = TN / (TN + FP + 1e-10)
    mcc = (TP*TN-FP*FN)/np.sqrt((TP + FP)*(TP + FN)*(TN + FP)*(TN + FN) + 1e-10)
    F1_score = 2*(precision*sensitivity)/(precision+sensitivity + 1e-10)
    return accuracy, sensitivity, precision, specificity, F1_score, mcc


# [Innovation 6] Embedding visualization tool – for result interpretation
def visualize_embeddings(embeddings, labels, title, save_path=None):
    """Visualize embeddings using t-SNE"""
    tsne = TSNE(n_components=2, random_state=42)
    embeddings_2d = tsne.fit_transform(embeddings.detach().cpu().numpy())
    
    plt.figure(figsize=(10, 8))
    scatter = plt.scatter(embeddings_2d[:, 0], embeddings_2d[:, 1], c=labels, cmap='viridis', alpha=0.8)
    plt.colorbar(scatter)
    plt.title(title)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()


# [Innovation 6] Training visualization tool – monitor training process
def plot_training_curve(losses, title='Training Loss', save_path=None):
    """Plot training loss curve"""
    plt.figure(figsize=(10, 6))
    plt.plot(losses)
    plt.title(title)
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.grid(True)
    
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()


def get_data(data_ID, output_dim):
    """Load dataset and construct graph structure"""
    interaction = pd.read_csv(f'./dataset/dataset{data_ID}/interaction_dataset{data_ID}.csv',
                              delimiter=',', header=None)
    circRNA_feature = pd.read_csv(f'./dataset/dataset{data_ID}/ml.csv', delimiter=',', header=None)
    disease_feature = pd.read_csv(f'./dataset/dataset{data_ID}/mp.csv', delimiter=',', header=None)

    # Process circRNA features
    m_emb = torch.Tensor(circRNA_feature.values)
    print(f"CircRNA feature dimension: {m_emb.size()}")
    m_emb = torch.cat([m_emb, torch.zeros(m_emb.size(0), output_dim - m_emb.size(1))], dim=1)
    
    # Process disease features
    s_emb = torch.Tensor(disease_feature.values)
    print(f"Disease feature dimension: {s_emb.size()}")
    s_emb = torch.cat([s_emb, torch.zeros(s_emb.size(0), output_dim - s_emb.size(1))], dim=1)

    # Merge features
    feature = torch.cat([m_emb, s_emb])

    # Build edge index
    l, p = interaction.values.nonzero()
    adj = torch.tensor([p, l + len(disease_feature)])
    data = Data(x=feature, edge_index=adj)

    # Data split
    train_data, _, test_data = T.RandomLinkSplit(
        num_val=0, 
        num_test=0.2,
        is_undirected=True, 
        split_labels=True,
        add_negative_train_samples=True
    )(data)
    
    splits = dict(train=train_data, test=test_data)
    return splits


# [Innovation 6] Multi-source feature fusion – enhance feature representation
def create_node_features(data_id, circrna_files=None, disease_files=None, output_dim=None):
    
    # Use default files if not provided
    if circrna_files is None:
        circrna_files = [f'./dataset/dataset{data_id}/ml.csv']
    
    if disease_files is None:
        disease_files = [f'./dataset/dataset{data_id}/mp.csv']
    
    # Load and concatenate circRNA features
    circrna_features = []
    for file in circrna_files:
        feat = pd.read_csv(file, delimiter=',', header=None).values
        circrna_features.append(torch.Tensor(feat))
    
    # Load and concatenate disease features
    disease_features = []
    for file in disease_files:
        feat = pd.read_csv(file, delimiter=',', header=None).values
        disease_features.append(torch.Tensor(feat))
    
    m_emb = torch.cat(circrna_features, dim=1) if len(circrna_features) > 1 else circrna_features[0]
    s_emb = torch.cat(disease_features, dim=1) if len(disease_features) > 1 else disease_features[0]
    
    if output_dim:
        m_emb = torch.cat([m_emb, torch.zeros(m_emb.size(0), max(0, output_dim - m_emb.size(1)))], dim=1)
        s_emb = torch.cat([s_emb, torch.zeros(s_emb.size(0), max(0, output_dim - s_emb.size(1)))], dim=1)
    
    return m_emb, s_emb


if __name__ == '__main__':
    # Test data loading
    data = get_data(2, 2048)
    print(f"Dataset Info: {data['train']}")
