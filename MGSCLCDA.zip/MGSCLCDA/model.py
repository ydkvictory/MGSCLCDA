import torch
import torch.nn.functional as F
import torch.nn as nn
from torch_sparse import SparseTensor
from torch.utils.data import DataLoader
from torch_geometric.nn import Linear, GINConv, GCNConv, GATConv, JumpingKnowledge
from torch_geometric.utils import add_self_loops, negative_sampling, degree, dropout_adj, to_dense_adj
from sklearn.metrics import roc_auc_score, average_precision_score
from utils import calculate_metrics

class PolyLoss(nn.Module):
    def __init__(self, DEVICE, weight_loss=None, epsilon=1.0):
        super(PolyLoss, self).__init__()
        self.CELoss = nn.CrossEntropyLoss(weight=weight_loss, reduction='none')
        self.epsilon = epsilon
        self.DEVICE = DEVICE

    def forward(self, predicted, labels):
        batch_size=labels.shape[0]
        one_hot = torch.zeros((batch_size, 2), device=self.DEVICE).scatter_(
            1, labels.to(torch.int64), 1)
        pt = torch.sum(one_hot * F.softmax(predicted, dim=1), dim=-1)
        ce = self.CELoss(predicted, labels.to(torch.float32))
        poly1 = ce + self.epsilon * (1-pt)
        return torch.mean(poly1)

# [Innovation 2] Dynamic adaptive aggregation mechanism – learns aggregation weights from input features
class DynamicAggregation(nn.Module):
    """Dynamically aggregates features with adaptive weights learned from input"""
    def __init__(self, channels):
        super(DynamicAggregation, self).__init__()
        # Weight generation network: outputs weights for sum, mean, max aggregation
        self.weight_net = nn.Sequential(
            nn.Linear(channels, channels // 4),
            nn.ReLU(),
            nn.Linear(channels // 4, 3),  # Weights for sum, mean, max
            nn.Softmax(dim=1)
        )
        
    def forward(self, x_sum, x_mean, x_max):
        # Compute adaptive weights (learned, not fixed)
        features = x_sum + x_mean + x_max  # Merge features to derive weights
        weights = self.weight_net(features)
        
        # Weighted aggregation based on learned weights
        x = weights[:, 0].unsqueeze(1) * x_sum + \
            weights[:, 1].unsqueeze(1) * x_mean + \
            weights[:, 2].unsqueeze(1) * x_max
            
        return x


# [Innovation 1] Multi-scale GNN architecture – integrates various convolutions and scales
class MultiscaleGNNBlock(nn.Module):
    """Multi-scale GNN block that integrates different convolution types"""
    def __init__(self, in_channels, hidden_channels, out_channels, dropout=0.5, heads=4):
        super(MultiscaleGNNBlock, self).__init__()
        
        # Innovation: use multiple GNN layers to capture structural information at different scales
        self.gin_conv = GINConv(Linear(in_channels, hidden_channels), train_eps=True)  # Multi-hop neighbors
        self.gcn_conv = GCNConv(in_channels, hidden_channels)  # Local structure aggregation
        self.gat_conv = GATConv(in_channels, hidden_channels // heads, heads=heads)  # Attention-based edge weights
        
        # Jumping Knowledge: integrates multiple GNN outputs
        self.jk = JumpingKnowledge(mode='cat', channels=hidden_channels, num_layers=3)
        
        # 特Fusion layer (to adapt JK output dimension)
        fusion_dim = hidden_channels * 3  
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, hidden_channels),
            nn.BatchNorm1d(hidden_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, out_channels)
        )
        
        # Backup fusion for mismatched JK output
        self.backup_fusion = nn.Sequential(
            nn.Linear(hidden_channels, out_channels),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Innovation: dynamic aggregation module
        self.aggregator = DynamicAggregation(hidden_channels)
        # self.aggregator = DynamicAggregation()
        
        self.bn = nn.BatchNorm1d(out_channels)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.ELU()

    def forward(self, x, edge_index, edge_attr=None):
        # Apply different GNN layers
        try:
            x_gin = self.gin_conv(x, edge_index)
            x_gcn = self.gcn_conv(x, edge_index)
            x_gat = self.gat_conv(x, edge_index)
            
            # Aggregate outputs
            x_sum = x_gin + x_gcn + x_gat
            x_mean = (x_gin + x_gcn + x_gat) / 3
            x_max = torch.max(torch.stack([x_gin, x_gcn, x_gat], dim=0), dim=0)[0]
            
            # Dynamic aggregation instead of simple concatenation or addition
            x_dynamic = self.aggregator(x_sum, x_mean, x_max)
            
            # Attempt Jumping Knowledge on all branches
            xs = [x_gin, x_gcn, x_gat]
            
            try:
                x_jk = self.jk(xs)
                
                print(f"x_dynamic shape: {x_dynamic.shape}, x_jk shape: {x_jk.shape}")
                

                x = self.backup_fusion(x_dynamic)
            except Exception as e:
                print(f"JumpingKnowledge error: {e}")
                x = self.backup_fusion(x_dynamic)
            
            x = self.bn(x)
            x = self.activation(x)
            x = self.dropout(x)
            
            return x
            
        except Exception as e:
            print(f"Error in MultiscaleGNNBlock forward pass: {e}")
            return torch.zeros((x.size(0), self.bn.num_features), device=x.device)

# [Innovation 3] Disentangled Path Encoder – models multiple relation types explicitly
class DisentangledPathEncoder(nn.Module):
    """Disentangles information from multiple path types (1-hop, 2-hop, 3-hop)"""
    def __init__(self, in_channels, hidden_channels, out_channels, n_paths=3):
        super(DisentangledPathEncoder, self).__init__()
        self.n_paths = n_paths
        
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        
        # Innovation: independent encoders for each path type
        self.path_encoders = nn.ModuleList([
            nn.Sequential(
                nn.Linear(in_channels, hidden_channels),
                nn.ReLU(),
                nn.Linear(hidden_channels, out_channels // n_paths)
            ) for _ in range(n_paths)
        ])
        
        # Path attention weights
        self.path_attention = nn.Sequential(
            nn.Linear(out_channels // n_paths, 1),
            nn.Sigmoid()
        )
        
        # Feature fusion layer
        self.fusion = nn.Linear(out_channels, out_channels)
        
        # Backup encoder
        self.backup_encoder = nn.Sequential(
            nn.Linear(in_channels, out_channels),
            nn.ReLU(),
            nn.Dropout(0.3)
        )
        
    def forward(self, x, edge_index):
        try:
            num_nodes = x.size(0)
            print(f"Encoder input: nodes={num_nodes}, dim={x.shape[1]}")
            
            if x.shape[1] != self.in_channels:
                print(f"Input dimension mismatch – using backup encoder")
                return self.backup_encoder(x)
            
            try:
                adj = to_dense_adj(edge_index, max_num_nodes=num_nodes)[0]
                print(f"Adjacency shape: {adj.shape}")
                
                if adj.shape[0] != x.shape[0]:
                    print(f"Adjacency and feature shape mismatch: adj={adj.shape[0]}, x={x.shape[0]}")
                    return self.backup_encoder(x)
                
                # Generate multi-hop adjacency
                paths = []
                
                path1 = adj
                paths.append(path1)
                
                try:
                    path2 = torch.matmul(adj, adj)
                    paths.append(path2)
                except Exception as e:
                    print(f"2-hop path computation failed, using 1-hop fallback: {e}")
                    paths.append(adj)
                
                try:
                    if len(paths) >= 2:
                        path3 = torch.matmul(paths[1], adj)
                    else:
                        path3 = torch.matmul(torch.matmul(adj, adj), adj)
                    paths.append(path3)
                except Exception as e:
                    print(f"3-hop path computation failed, using 1-hop fallback: {e}")
                    paths.append(adj)
                
                while len(paths) < self.n_paths:
                    paths.append(adj)
                
                path_features = []
                path_attentions = []
                
                for i in range(self.n_paths):
                    try:
                        print(f"Path {i} shape: {paths[i].shape}, x shape: {x.shape}")
                        
                        path_x = torch.matmul(paths[i], x)
                        
                        path_emb = self.path_encoders[i](path_x)
                        
                        path_features.append(path_emb)
                        
                        attention = self.path_attention(path_emb)
                        path_attentions.append(attention)
                    except Exception as e:
                        print(f"Error in path {i}: {e}")
                        path_emb = self.path_encoders[i](x)
                        path_features.append(path_emb)
                        attention = self.path_attention(path_emb)
                        path_attentions.append(attention)
                
            except Exception as e:
                print(f"Adjacency matrix error: {e}")
                path_features = []
                path_attentions = []
                
                for i in range(self.n_paths):
                    path_emb = self.path_encoders[i](x)
                    path_features.append(path_emb)
                    attention = self.path_attention(path_emb)
                    path_attentions.append(attention)
            
            # eature fusion
            try:
                for i, feat in enumerate(path_features):
                    print(f"Feature {i} shape: {feat.shape}")
                for i, attn in enumerate(path_attentions):
                    print(f"Attention {i} shape: {attn.shape}")
                
                path_attentions = torch.cat(path_attentions, dim=1)
                path_attentions = F.softmax(path_attentions, dim=1)
                
                path_features = torch.cat(path_features, dim=1)
                print(f"Merged feature shape: {path_features.shape}")
                
                try:
                    repeat_size = path_features.size(1) // path_attentions.size(1)
                    expanded_attention = path_attentions.repeat(1, repeat_size)
                    
                    if expanded_attention.shape != path_features.shape:
                        print("Attention and feature shape mismatch – fallback to uniform weights")
                        expanded_attention = torch.ones_like(path_features)
                    
                    weighted_features = path_features * expanded_attention
                except Exception as e:
                    weighted_features = path_features
                
                
                if weighted_features.shape[1] != self.fusion.in_features:
                    print(f"Shape mismatch in fusion layer – using temporary adapter")
                    temp_fusion = nn.Linear(weighted_features.shape[1], self.out_channels).to(weighted_features.device)
                    output = temp_fusion(weighted_features)
                else:
                    output = self.fusion(weighted_features)
                
                return output
            except Exception as e:
                print(f"Fusion error: {e}")
                return self.backup_encoder(x)
            
        except Exception as e:
            print(f"DisentangledPathEncoder overall error: {e}")
            return self.backup_encoder(x)

class GNNEncoder(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(GNNEncoder, self).__init__()
        
        # Save dimensional info
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        
        # Innovation Point: Use multiscale GNN blocks instead of standard GNN layers
        self.multiscale_block1 = MultiscaleGNNBlock(in_channels, hidden_channels, hidden_channels)
        self.multiscale_block2 = MultiscaleGNNBlock(hidden_channels, hidden_channels, out_channels)
        
        # Innovation Point: Disentangled path encoder
        self.path_encoder = DisentangledPathEncoder(out_channels, hidden_channels, out_channels)
        
        # Innovation Point: Feature enhancement layer to combine multiscale and path-based features
        self.feature_enhancer = nn.Sequential(
            nn.Linear(out_channels * 2, out_channels),
            nn.BatchNorm1d(out_channels),
            nn.ELU()
        )
        
        # Backup enhancement layer in case of dimensional mismatch
        self.backup_enhancer = nn.Sequential(
            nn.Linear(out_channels, out_channels),
            nn.BatchNorm1d(out_channels),
            nn.ELU()
        )
        
        self.dropout = nn.Dropout(0.5)
        self.activation = nn.ELU()
        
    def forward(self, x, edge_index):
        try:
            print(f"GNNEncoder input: x.shape = {x.shape}, edge_index.shape = {edge_index.shape}")
            
            try:
                edge_index_sparse = SparseTensor.from_edge_index(edge_index, sparse_sizes=(x.size(0), x.size(0)))
            except Exception as e:
                print(f"SparseTensor construction failed: {e}")
            
            # First multiscale GNN block
            x1 = self.multiscale_block1(x, edge_index)
            print(f"Block1 output: {x1.shape}")
            
            # Second multiscale GNN block
            x2 = self.multiscale_block2(x1, edge_index)
            print(f"Block2 output: {x2.shape}")
            
            try:
                # ath encoder to capture structural dependencies
                x_path = self.path_encoder(x2, edge_index)
                print(f"Path encoder output: {x_path.shape}")
                
                if x2.shape[1] + x_path.shape[1] == self.out_channels * 2:
                    x_combined = torch.cat([x2, x_path], dim=1)
                    x_enhanced = self.feature_enhancer(x_combined)
                else:
                    print(f"Dim mismatch: x2={x2.shape[1]}, x_path={x_path.shape[1]}, expected={self.out_channels * 2}")
                    x_enhanced = self.backup_enhancer(x2)
            except Exception as e:
                print(f"Path encoder or fusion error: {e}")
                x_enhanced = self.backup_enhancer(x2)
                
            return x_enhanced
            
        except Exception as e:
            print(f"GNNEncoder forward error: {e}")
            return torch.randn((x.size(0), self.out_channels), device=x.device) * 0.01


# [Innovation Point 4] Contrastive learning module – enhances model generalization through different graph views
class ContrastiveLearning(nn.Module):
    """Contrastive learning module to enhance model generalization via multiple augmented graph views."""
    def __init__(self, encoder, temperature=0.5):
        super(ContrastiveLearning, self).__init__()
        self.encoder = encoder
        self.temperature = temperature  # Temperature parameter for smoothing contrastive loss
        
        # Projection head – maps node embeddings to contrastive space
        self.projection = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 32)
        )
        
    def augment_graph(self, x, edge_index, edge_drop_p=0.2, feature_mask_p=0.2):
        # Innovation: Graph structure augmentation – randomly drop edges
        edge_index_aug, _ = dropout_adj(edge_index, p=edge_drop_p)
        
        # Innovation: Feature augmentation – randomly mask features
        feature_mask = torch.bernoulli(torch.ones_like(x) * (1 - feature_mask_p)).bool()
        x_aug = x * feature_mask
        
        return x_aug, edge_index_aug
        
    def forward(self, x, edge_index):
        # Innovation: Generate two augmented views
        x_aug1, edge_index_aug1 = self.augment_graph(x, edge_index) 
        x_aug2, edge_index_aug2 = self.augment_graph(x, edge_index)
        
        # Encode both views
        z1 = self.encoder(x_aug1, edge_index_aug1)
        z2 = self.encoder(x_aug2, edge_index_aug2)
        
        # Project to contrastive space
        p1 = self.projection(z1)
        p2 = self.projection(z2)
        
        # Normalize embeddings
        p1 = F.normalize(p1, dim=1)
        p2 = F.normalize(p2, dim=1)
        
        # Innovation: Compute similarity matrix and InfoNCE loss
        sim_matrix = torch.matmul(p1, p2.T) / self.temperature
        
        # Contrastive loss – encourages consistent representations for the same node across views
        labels = torch.arange(sim_matrix.size(0)).to(sim_matrix.device)
        loss = F.cross_entropy(sim_matrix, labels) + F.cross_entropy(sim_matrix.T, labels)
        loss = loss / 2
        
        return loss, z1  # Return contrastive loss and the first embedding

# [Innovation Point 5] Edge decoder enhanced by collaborative filtering
class EdgeDecoder(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(EdgeDecoder, self).__init__()
        
        # Save dimensional info for adaptive layer creation
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        
        # MLP decoder – traditional approach
        self.mlps = nn.ModuleList()
        self.mlps.append(nn.Linear(in_channels, hidden_channels))
        self.mlps.append(nn.Linear(hidden_channels, out_channels))
        
        # Innovation: Collaborative filtering enhancer – captures complex interaction patterns
        self.cf_enhancer = nn.Sequential(
            nn.Linear(in_channels * 2, hidden_channels),  # Adjusted to 2×in_channels to handle concatenated features
            nn.ReLU(),
            nn.Linear(hidden_channels, out_channels)
        )
        
        # Innovation: Fusion layer – combines different interaction features
        self.fusion = nn.Linear(out_channels * 2, out_channels)
        
        # Adapter layer – handles input dimension mismatch
        self.adapter = None
        
        # Backup decoder – for handling extreme fallback scenarios
        self.backup_decoder = nn.Linear(in_channels, out_channels)
        
        self.dropout = nn.Dropout(0.5)
        self.activation = nn.ELU()
        
    def forward(self, z, edge):
        # Innovation: Multiple methods for pairwise node interaction encoding
        x_hadamard = z[edge[0]] * z[edge[1]]  # Hadamard product – traditional method
        x_concat = torch.cat([z[edge[0]], z[edge[1]]], dim=1)  # Feature concatenation – richer interaction info
        
        # MLP decoding – based on Hadamard product
        x = x_hadamard
        for i, mlp in enumerate(self.mlps[:-1]):
            x = self.dropout(x)
            x = mlp(x)
            x = self.activation(x)
        x_mlp = self.mlps[-1](x)
        
        # Innovation: CF-enhanced decoding – based on feature concatenation
        x_cf = self.cf_enhancer(x_concat)
        
        # Innovation: Combine both decoding strategies
        x_combined = torch.cat([x_mlp, x_cf], dim=1)
        x_final = self.fusion(x_combined)
        
        return x_final

class DegreeDecoder(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels=1):
        super(DegreeDecoder, self).__init__()
        
        # Store dimension info for dynamic adapter creation
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.out_channels = out_channels
        
        self.mlps = nn.ModuleList()
        self.mlps.append(nn.Linear(in_channels, hidden_channels))
        self.mlps.append(nn.Linear(hidden_channels, out_channels))

        # Adapter layer – handles input dimension mismatches
        self.adapter = None
        
        self.dropout = nn.Dropout(0.5)
        self.activation = nn.ELU()

    def forward(self, x):
        try:
            # Check if input feature dimension matches expected dimension
            if x.shape[1] != self.in_channels:
                print(f"DegreeDecoder: Feature dimension mismatch. Expected {self.in_channels}, got {x.shape[1]}. Creating adapter.")
                
                # Dynamically create an adapter if it doesn't exist or has mismatched dimensions
                if self.adapter is None or self.adapter.in_features != x.shape[1]:
                    self.adapter = nn.Linear(x.shape[1], self.in_channels).to(x.device)
                    
                # Adjust feature dimension using the adapter
                x = self.adapter(x)
                
            for i, mlp in enumerate(self.mlps[:-1]):
                x = mlp(x)
                x = self.dropout(x)
                x = self.activation(x)
            x = self.mlps[-1](x)
            x = self.activation(x)
            return x
            
        except Exception as e:
            print(f"DegreeDecoder forward error: {e}")
            # Fallback: return zero tensor with correct shape
            return torch.zeros((x.size(0), self.out_channels), device=x.device)

def ce_loss(pos_out, neg_out):
    pos_loss = F.binary_cross_entropy(pos_out.sigmoid(), torch.ones_like(pos_out))
    neg_loss = F.binary_cross_entropy(neg_out.sigmoid(), torch.zeros_like(neg_out))
    
    return pos_loss + neg_loss

# [Overall Innovation Architecture] Enhanced MGSCLCDA model – integrates all proposed modules
class MGSCLCDA_Enhanced(nn.Module):
    def __init__(self, encoder, edge_decoder, degree_decoder, mask, contrastive_weight=0.1):
        super(MGSCLCDA_Enhanced, self).__init__()
        self.encoder = encoder
        self.edge_decoder = edge_decoder
        self.degree_decoder = degree_decoder
        self.mask = mask
        self.negative_sampler = negative_sampling
        self.poly_loss = PolyLoss(DEVICE=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        self.contrastive_weight = contrastive_weight  # Contrastive loss weight
        
        # Innovation: Add contrastive learning module
        self.contrastive = ContrastiveLearning(encoder)
        
    def loss_fn(self, pos_out, neg_out):
        pos_one_hot = torch.tensor([[0,1]]).repeat(len(pos_out),1)
        neg_one_hot = torch.tensor([[1,0]]).repeat(len(neg_out),1)
        pos_loss = self.poly_loss(pos_out, pos_one_hot)
        neg_loss = self.poly_loss(neg_out, neg_one_hot)
        return pos_loss + neg_loss
    
    def train_epoch(self, data, optimizer, alpha, batch_size=1024, grad_norm=1.0):
        x, edge_index = data.x, data.edge_index
        remaining_edges, masked_edges = self.mask(edge_index)
        
        # Add self-loops
        try:
            aug_edge_index, _ = add_self_loops(edge_index)
        except Exception as e:
            print(f"Error adding self-loops: {e}")
            aug_edge_index = edge_index
        
        # Negative sampling
        try:
            neg_edges = self.negative_sampler(
                aug_edge_index, num_nodes=data.num_nodes, num_neg_samples=masked_edges.view(2, -1).size(1)
            ).view_as(masked_edges)
        except Exception as e:
            print(f"Negative sampling error: {e}")
            # Fallback: generate random negative edges
            neg_edges = torch.randint(0, data.num_nodes, masked_edges.shape, device=masked_edges.device)
        
        total_loss = 0
        
        # Reduce batch size to lower memory usage and avoid dimension mismatches
        batch_size = min(batch_size, 512)
        print(f"Using batch size: {batch_size}")
        
        for perm in DataLoader(range(masked_edges.size(1)), batch_size=batch_size, shuffle=True):
            try:
                optimizer.zero_grad()
                
                # Contrastive loss – with exception handling
                try:
                    contrastive_loss, z = self.contrastive(x, remaining_edges)
                    if z is None:
                        print("Contrastive learning returned None. Using default encoder.")
                        z = self.encoder(x, remaining_edges)
                        contrastive_loss = torch.tensor(0.0, device=x.device)
                except Exception as e:
                    print(f"Contrastive learning error: {e}")
                    contrastive_loss = torch.tensor(0.0, device=x.device)
                    z = self.encoder(x, remaining_edges)
                
                print(f"Node embedding shape: {z.shape}")
                
                # Edge prediction loss – main task
                batch_masked_edges = masked_edges[:, perm]
                batch_neg_edges = neg_edges[:, perm]
                
                try:
                    pos_out = self.edge_decoder(z, batch_masked_edges)
                    neg_out = self.edge_decoder(z, batch_neg_edges)
                    edge_loss = self.loss_fn(pos_out, neg_out)
                except Exception as e:
                    print(f"Edge prediction error: {e}")
                    edge_loss = torch.tensor(1.0, device=z.device)
                
                # Degree prediction loss – auxiliary task to model graph topology
                try:
                    deg = degree(masked_edges[1].flatten(), data.num_nodes).float()
                    degree_loss = F.mse_loss(self.degree_decoder(z).squeeze(), deg)
                except Exception as e:
                    print(f"Degree prediction error: {e}")
                    degree_loss = torch.tensor(0.1, device=z.device)
                
                # Innovation: Multi-task learning – total loss combines three supervisory signals
                contrastive_weight = min(self.contrastive_weight, 0.01)  # Limit contrastive loss impact
                loss = edge_loss + alpha * degree_loss + contrastive_weight * contrastive_loss
                total_loss += loss.item()
                
                # Backpropagation
                try:
                    loss.backward()
                    nn.utils.clip_grad_norm_(self.parameters(), grad_norm)
                    optimizer.step()
                except Exception as e:
                    print(f"Backpropagation error: {e}")
                    continue
                    
            except Exception as e:
                print(f"Batch processing error: {e}")
                continue
        
        return total_loss

    @torch.no_grad()
    def batch_predict(self, z, edges, batch_size=2 ** 16):
        preds = []
        for perm in DataLoader(range(edges.size(1)), batch_size):
            edge = edges[:, perm]
            preds += [self.edge_decoder(z, edge).squeeze().cpu()]
        pred = torch.cat(preds, dim=0)
        pred = F.softmax(pred,dim=1)[:,1]
        return pred

    @torch.no_grad()
    def test(self, z, pos_edge_index, neg_edge_index):
        pos_pred = self.batch_predict(z, pos_edge_index)
        neg_pred = self.batch_predict(z, neg_edge_index)

        pred = torch.cat([pos_pred, neg_pred], dim=0)
        pos_y = pos_pred.new_ones(pos_pred.size(0))
        neg_y = neg_pred.new_zeros(neg_pred.size(0))

        y = torch.cat([pos_y, neg_y], dim=0)
        y, pred = y.cpu().numpy(), pred.cpu().numpy()

        auc = roc_auc_score(y, pred)
        ap = average_precision_score(y, pred)
        temp = torch.tensor(pred)
        temp[temp >= 0.5] = 1
        temp[temp < 0.5] = 0
        acc, sen, pre, spe, F1, mcc = calculate_metrics(y, temp.cpu())
        return auc, ap, acc, sen, pre, spe, F1, mcc

GMAE = MGSCLCDA_Enhanced

