import torch
import argparse
import numpy as np
from mask import Mask
from utils import get_data, set_seed, setup_logger, plot_training_curve
from model import GNNEncoder, EdgeDecoder, DegreeDecoder, MGSCLCDA_Enhanced

# Command-line arguments
parser = argparse.ArgumentParser()
parser.add_argument("--dataset", type=int, default=1, help="Select dataset (1 or 2)")
parser.add_argument('--seed', type=int, default=2023, help="Random seed for model and dataset")
parser.add_argument('--dim', type=int, default=2825, help='Feature dimension')
parser.add_argument('--alpha', type=float, default=0.007, help='Loss weight for degree-based prediction')
# [Innovation 4] Contrastive learning loss weight
parser.add_argument('--contrastive_weight', type=float, default=0.01, help='Loss weight for contrastive learning')
parser.add_argument('--p', type=float, default=0.4, help='Edge masking ratio for graph augmentation')
parser.add_argument('--epochs', type=int, default=1000, help='Number of training epochs')
parser.add_argument('--learning_rate', type=float, default=1e-3, help='Learning rate')
parser.add_argument('--weight_decay', type=float, default=5e-5, help='Weight decay for regularization')
parser.add_argument('--hidden_dim', type=int, default=64, help='Dimension of hidden layers')
parser.add_argument('--output_dim', type=int, default=128, help='Dimension of output embeddings')
# Add batch size parameter
parser.add_argument('--batch_size', type=int, default=256, help='Mini-batch size during training')
args = parser.parse_args()

# Set random seed
set_seed(args.seed)

logger = setup_logger('MGSCLCDA')
logger.info(f"Parameter configuration: {vars(args)}")
logger.info(f"Device in use: {torch.device('cpu')}")

# Load data
try:
    splits = get_data(args.dataset, args.dim)
    logger.info(f"Data loaded successfully, dataset{args.dataset}")
except Exception as e:
    logger.error(f"Failed to load data: {e}")
    raise

# Define model components
try:
    # [Innovation 1] Use multiscale GNN encoder
    encoder = GNNEncoder(in_channels=args.dim, hidden_channels=args.hidden_dim, out_channels=args.output_dim)
    # [Innovation 5] Use collaborative filtering–enhanced edge decoder
    edge_decoder = EdgeDecoder(in_channels=args.output_dim, hidden_channels=args.hidden_dim, out_channels=2)
    degree_decoder = DegreeDecoder(in_channels=args.output_dim, hidden_channels=args.hidden_dim, out_channels=1)
    mask = Mask(p=args.p)

    # Initialize model instance – integrating all innovations
    model = MGSCLCDA_Enhanced(
        encoder=encoder, 
        edge_decoder=edge_decoder, 
        degree_decoder=degree_decoder,
        mask=mask,
        contrastive_weight=args.contrastive_weight  # Contrastive learning loss weight
    )
    logger.info("Model initialized successfully")
except Exception as e:
    logger.error(f"Model initialization failed: {e}")
    raise

# Optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)

# [Innovation 6] Add learning rate scheduler – adaptive adjustment
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, mode='min', factor=0.5, patience=20, min_lr=1e-6, verbose=True
)

# Global exception handling
try:
    best_loss = float('inf')
    train_losses = []

    logger.info("Training started...")
    for epoch in range(args.epochs):
        model.train()
        try:
            # [Innovation 4] Train with contrastive loss, use batch size from command line
            loss = model.train_epoch(splits['train'], optimizer, alpha=args.alpha, batch_size=args.batch_size)
            train_losses.append(loss)
            
            # Update learning rate
            scheduler.step(loss)
            
            # [Innovation 6] Log training progress every 100 epochs
            if (epoch + 1) % 10 == 0:
                logger.info(f'Epoch: {epoch+1}/{args.epochs}, Training Loss: {loss:.6f}')
                
                # [Innovation 6] Save best model – checkpointing
                if loss < best_loss:
                    best_loss = loss
                    torch.save(model.state_dict(), f'best_model_dataset{args.dataset}.pt')
                    logger.info(f'Model saved (Loss: {best_loss:.6f})')
        except Exception as e:
            logger.error(f"Error in epoch {epoch+1}: {e}")
            # Continue training despite errors
            continue
    
    # Load the best model and evaluate
    try:
        model.load_state_dict(torch.load(f'best_model_dataset{args.dataset}.pt'))
        model.eval()
        test_data = splits['test']
        
        # Wrap encoder in try-except
        try:
            z = model.encoder(test_data.x, test_data.edge_index)
            
            # Evaluate test performance
            test_auc, test_ap, acc, sen, pre, spe, F1, mcc = model.test(
                z, test_data.pos_edge_label_index, test_data.neg_edge_label_index
            )
            
            # Format results
            results = {
                'AUC': "{:.6f}".format(test_auc),
                'AP': "{:.6f}".format(test_ap),
                "ACC": "{:.6f}".format(acc),
                "SEN": "{:.6f}".format(sen),
                "PRE": "{:.6f}".format(pre),
                "SPE": "{:.6f}".format(spe),
                "F1": "{:.6f}".format(F1),
                "MCC": "{:.6f}".format(mcc)
            }
            
            # [Innovation 6] Log final test results
            logger.info(f"Test results: {results}")
            print(results)
            
            # [Innovation 6] Plot training loss curve
            plot_training_curve(train_losses, title='Training Loss of MGSCLCDA', save_path='training_loss.png')
        except Exception as e:
            logger.error(f"Error during testing/encoding phase: {e}")
            print("Model training completed, but an error occurred during testing.")
    except Exception as e:
        logger.error(f"Error loading model or testing: {e}")
        print("Model training completed, but error occurred in model loading or testing.")
        
except Exception as e:
    logger.error(f"Global execution error: {e}")
    print(f"Execution failed: {e}")
